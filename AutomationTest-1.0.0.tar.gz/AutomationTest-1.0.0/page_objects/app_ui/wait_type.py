# 作者 yanchunhuo
# 创建时间 2018/01/19 22:36
# github https://github.com/yanchunhuo
class Wait_Type:
    TITLE_IS = 'title_is'
    TITLE_CONTAINS = 'title_contains'
    PRESENCE_OF_ELEMENT_LOCATED = 'presence_of_element_located'
    ELEMENT_LOCATED_TO_BE_SELECTED = 'element_located_to_be_selected'
    ELEMENT_TO_BE_CLICKABLE = 'element_to_be_clickable'
    VISIBILITY_OF = 'visibility_of'