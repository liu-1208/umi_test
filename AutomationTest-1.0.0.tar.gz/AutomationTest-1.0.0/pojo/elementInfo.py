#-*- coding:utf8 -*-
# 作者 yanchunhuo
# 创建时间 2018/01/19 22:36
# github https://github.com/yanchunhuo
class ElementInfo:
    def __init__(self):
        self.locator_type=None
        self.locator_value=None
        self.expected_value=None
        self.wait_type=None
        self.wait_seconds=None
        self.wait_expected_value=None