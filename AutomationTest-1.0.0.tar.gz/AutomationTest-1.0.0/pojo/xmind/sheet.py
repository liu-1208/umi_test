# 作者 yanchunhuo
# 创建时间 2018/01/19 22:36
# github https://github.com/yanchunhuo
class Sheet:
    def __init__(self):
        self.sheetName=None
        self.rootTopic=None